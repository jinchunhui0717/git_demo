/*
*   SSMA informational messages:
*   M2SS0003: The following SQL clause was ignored during conversion:
*   DEFINER = `equipinspect`@`%`.
*/

CREATE TRIGGER dbo.InsteadOfUpdateOn_sys_user_role
   ON dbo.sys_user_role
    INSTEAD OF UPDATE
      AS 
         BEGIN

            SET  NOCOUNT  ON

            SET  XACT_ABORT  ON

            /* column variables declaration*/
            DECLARE
               @old$ssma$rowid uniqueidentifier, 
               @new$user_id nvarchar(64), 
               @new$role_id nvarchar(64), 
               @new$create_by nvarchar(64), 
               @new$create_date datetime, 
               @new$update_by nvarchar(64), 
               @new$update_date datetime

            DECLARE
                ForEachInsertedRowTriggerCursor CURSOR LOCAL FORWARD_ONLY READ_ONLY FOR 
                  SELECT 
                     i.user_id, 
                     i.role_id, 
                     i.create_by, 
                     i.create_date, 
                     i.update_by, 
                     i.update_date, 
                     d.ssma$rowid
                  FROM 
                     deleted  AS d 
                        INNER JOIN inserted  AS i 
                        ON i.ssma$rowid = d.ssma$rowid

            OPEN ForEachInsertedRowTriggerCursor

            FETCH ForEachInsertedRowTriggerCursor
                INTO 
                  @new$user_id, 
                  @new$role_id, 
                  @new$create_by, 
                  @new$create_date, 
                  @new$update_by, 
                  @new$update_date, 
                  @old$ssma$rowid

            WHILE @@fetch_status = 0
            
               BEGIN

                  /* row-level triggers implementation: begin*/
                  BEGIN
                     SET @new$update_date = getdate()
                  END
                  /* row-level triggers implementation: end*/

                  /* DML-operation emulation*/
                  UPDATE dbo.sys_user_role
                     SET 
                        user_id = @new$user_id, 
                        role_id = @new$role_id, 
                        create_by = @new$create_by, 
                        create_date = @new$create_date, 
                        update_by = @new$update_by, 
                        update_date = @new$update_date
                  WHERE ssma$rowid = @old$ssma$rowid

                  FETCH ForEachInsertedRowTriggerCursor
                      INTO 
                        @new$user_id, 
                        @new$role_id, 
                        @new$create_by, 
                        @new$create_date, 
                        @new$update_by, 
                        @new$update_date, 
                        @old$ssma$rowid

               END

            CLOSE ForEachInsertedRowTriggerCursor

            DEALLOCATE ForEachInsertedRowTriggerCursor

         END
go

exec sp_addextendedproperty 'MS_SSMA_SOURCE', N'equipinspect.sys_user_role.update_sys_user_role', 'SCHEMA', 'dbo',
     'TABLE', 'sys_user_role', 'TRIGGER', 'InsteadOfUpdateOn_sys_user_role'
go

